/*
 * delay.h
 *
 *  Created on: Jul 30, 2024
 *      Author: jsmok
 */

#ifndef INC_DELAY_H_
#define INC_DELAY_H_

#include "top.h"
#include "tim.h"

void delay_us(uint16_t us);



#endif /* INC_DELAY_H_ */
